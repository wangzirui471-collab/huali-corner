@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 请先停止正在运行的转角网站服务，再选择现用数据目录。
python "%~dp0demote_staff.py" --nickname godfly
echo.
pause
